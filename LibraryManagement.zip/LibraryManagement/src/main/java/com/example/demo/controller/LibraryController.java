package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Library;
import com.example.demo.service.LibraryService;

@Controller
public class LibraryController 
{
	@Autowired
	private LibraryService service;
	
	 @GetMapping("/")
	    public String viewHomePage(Model model)
	    {
	    	List<Library> listStu = service.listAll();
	    	model.addAttribute("listlibrary" ,listStu);
	    	System.out.println("Get/");
			return "index";
	    	
	    }
		
	    @GetMapping("/new")
	    public String add(Model model)
	    {
	    	model.addAttribute("library" , new Library());
	    	return "NewFile";
	    	
	    }
	    
	    @RequestMapping(value="/save" ,method = RequestMethod.POST)
	    public String saveStudent(@ModelAttribute("library") Library lib) //student is from html
	    {
	    	service.save(lib);
	    	return "redirect:/"; 
	    }
	    @RequestMapping("/edit/{id}")
	    public ModelAndView showEditPage(@PathVariable(name = "id") int id)
	    {
	    	ModelAndView mv = new ModelAndView("NewFile");
			Library std = service.get(id);
			mv.addObject("library",std);
			return mv;
	    	
	    }
	    @RequestMapping("/delete/{id}")
	    public String deleteStu(@PathVariable(name = "id") int id)
	    {
	    	service.delete(id);
	    	return "redirect:/";
	    	
	    }
}
