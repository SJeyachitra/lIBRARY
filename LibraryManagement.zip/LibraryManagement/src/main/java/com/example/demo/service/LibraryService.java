package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.LibraryRepository;
import com.example.demo.model.Library;

@Service
public class LibraryService
{
	@Autowired
	private LibraryRepository dao;
	
	public List<Library> listAll()
	{
		return dao.findAll();
	}
	
	public void save(Library l)
	{
		dao.save(l);
	}
	
	public Library get(int id)
	{
		return dao.findById(id).get();
	}
	
	public void delete(int id)
	{
		dao.deleteById(id);
	}
}
